# ============================================================
# timeline_vertex.py
# Extract Event Timeline from News using Vertex AI (Gemini 1.5)
# ============================================================

import json
import time
import traceback
from vertexai import init
from vertexai.generative_models import GenerativeModel

# ------------------ CONFIG ------------------

PROJECT_ID = "instr-cs795-fall25-hqin-1"  # <---- Cambia esto
LOCATION = "us-central1"

MODEL_NAME = "gemini-2.0-flash"
PROMPT_PATH = "../prompt/prompt-timeline.txt"

# ------------------ INIT MODEL ------------------

init(project=PROJECT_ID, location=LOCATION)
model = GenerativeModel(MODEL_NAME)

# ------------------ HELPER FUNCTIONS ------------------

def load_prompt():
    with open(PROMPT_PATH, "r", encoding="utf-8") as f:
        return f.read()

BASE_PROMPT = load_prompt()

def build_prompt(narrative_text, publication_date):
    """
    Inserta los datos reales dentro del prompt plantilla.
    """
    return (
        BASE_PROMPT.replace("{narrative_text}", narrative_text)
                   .replace("{PublicationDate}", publication_date)
    )

def call_gemini(prompt, max_retries=5):
    """
    Llamada segura al modelo Gemini con reintentos.
    """
    for attempt in range(max_retries):
        try:
            response = model.generate_content(
                prompt,
                generation_config={
                    "temperature": 0.2,
                    "top_p": 0.9,
                    "max_output_tokens": 4096,
                }
            )
            return response.text
        except Exception as e:
            print(f"⚠️ Error in Gemini call: {e}")
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError("❌ Vertex AI Maximum Retry Failure")

def parse_json_response(response_text):
    """
    Intenta extraer JSON incluso si viene con codeblocks.
    """
    try:
        return json.loads(response_text)
    except:
        try:
            cleaned = response_text.strip("` \n")
            return json.loads(cleaned)
        except:
            print("❌ JSON Parsing Error")
            print(response_text)
            raise

def extract_timeline(article, narrative_field="narrative"):
    """
    Procesa un artículo, construye el prompt y devuelve timeline JSON.
    """
    prompt = build_prompt(article[narrative_field], article["PublicationDate"])
    response_text = call_gemini(prompt)
    parsed_json = parse_json_response(response_text)

    parsed_json["title"] = article.get("title", None)
    parsed_json["url"] = article.get("url", None)
    parsed_json["source"] = article.get("source", None)
    parsed_json["section"] = article.get("section", None)

    return parsed_json

# ------------------ MAIN EXAMPLE ------------------

if __name__ == "__main__":
    # EJEMPLO: puedes cargar un dataset .json, .txt, CSV, etc.
    sample_article = {
        "title": "Mozambique rocked by killing of two prominent opposition figures",
        "url": "https://www.africanews.com/2024/10/20/mozambique-rocked-by-killing-of-two-prominent-opposition-figures/",
        "source": "Africanews",
        "section": "Africa",
        "PublicationDate": "2024-10-20",
        "narrative": open("../data/narrative.txt", "r", encoding="utf-8").read()
    }

    try:
        result = extract_timeline(sample_article)
        print("\n📌 TIMELINE RESULT:\n")
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except Exception as e:
        print("🚨 Error processing narrative:", e)
        traceback.print_exc()